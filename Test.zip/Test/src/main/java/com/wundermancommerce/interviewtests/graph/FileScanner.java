package com.wundermancommerce.interviewtests.graph;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;


public class FileScanner {

	//class to parse data from document to objects
	
	ArrayList<People> peopleList = new ArrayList<People>();
	ArrayList<Relationships> relationList = new ArrayList<Relationships>();
	
	String row;
	String row2;
	
	
	String x;
	String y;
	String z;
	
	String x2;
	String y2;
	String z2;
	
	// sets file to read
	public void setFile() throws IOException
	{
		
		File csvFile = new File("src/test/resources/people.csv");
			if(csvFile.isFile()) { // Checking file contents
				BufferedReader csvReader = new BufferedReader(new FileReader("src/test/resources/people.csv"));	// File stored in the buffered reader under new FileReader		
				while((row = csvReader.readLine()) != null) {							
					String peopleData[] = row.split(","); // splits each word at ","				
					for(int i = 0; i < peopleData.length; i++) {					
						x = peopleData[i];
						y = peopleData[i+1];
						z = peopleData[i+2]; //iterating across the array for 3 fields												
						setPeople(x, y, z); //sets Name, Age, Email -> people object					
						i = i + 3; 
					}
					
					
				}
				csvReader.close();
								
			}

		File csvFile2 = new File("src/test/resources/relationships.csv");
			if(csvFile2.isFile()) {
				BufferedReader csv2Reader = new BufferedReader(new FileReader("src/test/resources/relationships.csv"));
				while((row2 = csv2Reader.readLine()) != null) {
					if(row2.length() > 0 ) {
					String relationshipData[] = row2.split(",");
					for(int i = 0; i < relationshipData.length; i++) {
						x2 = relationshipData[i]; // email1
						y2 = relationshipData[i + 1]; // relation
						z2 = relationshipData[i + 2]; // email 2
						
						setRelationship(x2, y2, z2); 
						
						i = i + 3;
					}
					}
				}
				csv2Reader.close();
							
			}
	}
	
	
	//sets file data to object and object to array
	private void setPeople(String Name, String Email, String Age) {
		People newPerson = new People(Name, Email, Age); // stores list of people in array
		peopleList.add(newPerson); // adds this.People to array list
	}
	
	private void setRelationship(String EmailOne, String Relationship, String EmailTwo) {
		Relationships newRelationship = new Relationships(EmailOne, Relationship, EmailTwo);
		relationList.add(newRelationship);
	}
	
	public ArrayList<Relationships> getArrayListRelation(){
		return(relationList);
	}
	
	public int getArrayRelationLength() {
		return(relationList.size());
	}
	
	
	public ArrayList<People> getArrayListPeople(){
		return(peopleList);
	}
		
	public int getArrayLength() {
		return(peopleList.size());
	}
}

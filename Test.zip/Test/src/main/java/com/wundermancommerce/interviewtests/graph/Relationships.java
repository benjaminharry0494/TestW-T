package com.wundermancommerce.interviewtests.graph;

public class Relationships {
	String email1; //customer 1 email
	String relation; //customer name
	String email2; // customer 2 email	
	
	// constructor
	Relationships(String Email1, String Relation, String Email2){
		setRelation(Relation);
		setEmail(Email1);
		setEmail2(Email2);
	}
	
	// getters and setters for Relationship class
	
	private void setRelation(String Relation) {
		this.relation = Relation;
	}
	
	private void setEmail(String Email1) {
		this.email1 = Email1;
	}
	
	private void setEmail2(String Email2) {
		this.email2 = Email2;
	}
	
	public String getRelation() {
		return this.relation;
	}
	
	public String getEmail1() {
		return this.email1;
	}
	
	public String getEmail2() {
		return this.email2;
	}
}

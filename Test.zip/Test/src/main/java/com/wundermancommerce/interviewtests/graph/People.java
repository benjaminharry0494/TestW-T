package com.wundermancommerce.interviewtests.graph;

	// People class, information parsed from file scanner


public class People {
	String name; //customer name
	String email; //customer email
	String age; // customer age	
	
	// constructor
	People(String Name, String Email, String Age){
		setName(Name);
		setEmail(Email);
		setAge(Age);
	}
	
	People(){
		
	}
	
	// getters and setters for People class
	
	private void setName(String Name) {
		this.name = Name;
	}
	
	private void setEmail(String Email) {
		this.email = Email;
	}
	
	private void setAge(String Age) {
		this.age = Age;
	}
	
	public String getName() {
		return this.name;
	}
	
	public String getEmail() {
		return this.email;
	}
	
	public String getAge() {
		return this.age;
	}
}

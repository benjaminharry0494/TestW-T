package com.wundermancommerce.interviewtests.graph;

import java.io.IOException;
import java.util.ArrayList;

public class Test {
	
	String Email;
	String Name; 
	int Relationships;
	
	ArrayList<String> relationList = new ArrayList<String>();
	
	static FileScanner filescanner = new FileScanner();
	
	public void testOne(int input1) throws IOException {
		filescanner.setFile();
		
		Email = filescanner.getArrayListPeople().get(input1 - 1).getEmail();
		
		for(int x = 0; x < filescanner.getArrayRelationLength(); x++) {
			if(Email.equals(filescanner.getArrayListRelation().get(x).getEmail1()) || Email.equals(filescanner.getArrayListRelation().get(x).getEmail2())){
				Relationships++;
			}
		}
		System.out.println(filescanner.getArrayListPeople().get(input1 - 1).getName() + " has " + Relationships + " relationships...");
	}
	
	public int  testTwo(People newPerson) {
		
		Name = newPerson.getName();
		Email = newPerson.getEmail();
		
		relationList.add(Email);
		
		String familyEmail;
		String Relation = "FAMILY";
		int totalNumberOfFamilyRelations = 1; //counts self
		
		
		for(int x = 0; x < filescanner.getArrayRelationLength(); x++) {  // scan relationship data array
			
			
			if(Email.equals(filescanner.getArrayListRelation().get(x).getEmail1()) || Email.equals(filescanner.getArrayListRelation().get(x).getEmail2())){ //if newPerson email = Email 1 or Email 2 continue
				
				
				if(filescanner.getArrayListRelation().get(x).getRelation().equals(Relation)){ // if relationship is family continue
										
					
					if(!Email.equals(filescanner.getArrayListRelation().get(x).getEmail2())) { 
						familyEmail = filescanner.getArrayListRelation().get(x).getEmail2();  // get 2nd email 
						for(int y = 0; y < relationList.size(); y++) {
							if(!relationList.contains(familyEmail)) { // if entry not already in array list
								setRelationList(familyEmail);
								totalNumberOfFamilyRelations++;//add family email
							}
						}
					}
					if(!Email.equals(filescanner.getArrayListRelation().get(x).getEmail1())) {
						familyEmail = filescanner.getArrayListRelation().get(x).getEmail1(); // get 1st email 
						for(int y = 0; y < relationList.size(); y++) {
							if(!relationList.contains(familyEmail)) {
								setRelationList(familyEmail);
								totalNumberOfFamilyRelations++; //add family email
								}
							}
						}
					}
				}
			}
		
		
		//extended family
		for(int i = 0; i < relationList.size(); i++) {
			for(int x = 0; x < filescanner.getArrayRelationLength(); x++ ) {
				if(relationList.get(i).equals(filescanner.getArrayListRelation().get(x).getEmail1()) || relationList.get(i).equals(filescanner.getArrayListRelation().get(x).getEmail2())){
					if(filescanner.getArrayListRelation().get(x).getRelation().equals(Relation)){
						if(!relationList.get(i).equals(filescanner.getArrayListRelation().get(x).getEmail1())){
							familyEmail = filescanner.getArrayListRelation().get(x).getEmail1();
							for(int y = 0; y < relationList.size(); y++) {
								if(!relationList.contains(familyEmail)) {
									setRelationList(familyEmail);
									totalNumberOfFamilyRelations++;
								}
							}
						}
						
						if(!relationList.get(i).equals(filescanner.getArrayListRelation().get(x).getEmail2())){
							familyEmail = filescanner.getArrayListRelation().get(x).getEmail2();
							for(int y = 0; y < relationList.size(); y++) {
								if(!relationList.contains(familyEmail)) {
									setRelationList(familyEmail);
									totalNumberOfFamilyRelations++;
								}
							}
						}
					}
				}
			}
		}
		return totalNumberOfFamilyRelations++;
	}
	
	private void setRelationList(String FamilyEmail) {
		
		relationList.add(FamilyEmail);
		//System.out.println(relationList.size());
		//System.out.println("Added member " + FamilyEmail);
	}
	
}



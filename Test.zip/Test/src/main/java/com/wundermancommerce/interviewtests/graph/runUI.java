package com.wundermancommerce.interviewtests.graph;

import java.io.IOException;
import java.util.Scanner; 

public class runUI {
	
	//runs basic UI, calls FileScanner methods - displays output and UI to user
	
	static FileScanner filescanner = new FileScanner();
	static Test tests = new Test();
	static boolean isValid = true;
	static boolean relationCheck = true;
	static boolean mainMenu = true;
	static Scanner scanner = new Scanner(System.in);
	
	public static void main(String[] args) throws IOException {
		
		start();
	}
	
	//calls methods
	static void start() throws IOException {
		filescanner.setFile();
		System.out.println("People file is found");
		System.out.println("Relationships file is found");
		userInput();
	}
	
	//deals with user interface
	static void userInput() throws IOException {
		String Age;
		String Email;
		String Email1; // strictly used for relation checker
		String Email2; // strictly used for relation checker
		String Relation; 
		String Name;
		String Name2; // strictly used for relation checker
		int input;
		int input2; // strictly used for relation checker
		
		for(int x = 0; x < 2; x++) { 
			mainMenu: // label to return
		while(mainMenu) {
			System.out.println("Welcome to Benjamin Harry's exercise solution..."); 
			System.out.println("The system has " + filescanner.getArrayLength() + " entries..."); // total number of entries
			System.out.println("1. Please press 1 if you would like to view the entries...");
			System.out.println("2. Please press 2 if you would like to view the relationship status of two entries...");
			System.out.println("3. Please press 3 if you would like to run tests.. ");
			input = scanner.nextInt();
		if(input == 1) {
		while(isValid) {
		System.out.println("Please enter the number of the entry you would like to see, or press 0 to view all entries...");
		input = scanner.nextInt();
		if(input == 0) {
			for(int i = 0; i < filescanner.getArrayLength(); i++) { //loops array length 
					Age = filescanner.getArrayListPeople().get(i).getAge(); // returns age
					Email = filescanner.getArrayListPeople().get(i).getEmail(); // returns email
					Name = filescanner.getArrayListPeople().get(i).getName(); // returns name
					
					System.out.println("Entry number " + (i + 1) + " is: " + Name + " " + Age + " " + Email); // displays all entries
					isValid = false;
					}

			}
			if(input != 0 ) {
					Age = filescanner.getArrayListPeople().get(input - 1).getAge(); // makes entries look nicer when they are 1-12 instead of 0-11
					Email = filescanner.getArrayListPeople().get(input - 1).getEmail();
					Name = filescanner.getArrayListPeople().get(input - 1).getName();
							
					System.out.println("Entry number " + input + " is: " + Name + ", " + Age + ", " + Email);
			}
			
			}
		continue mainMenu;
		}
		if(input == 2) {
			for(int i = 0; i < filescanner.getArrayLength(); i++) { //loops array length 
				Age = filescanner.getArrayListPeople().get(i).getAge(); // returns age
				Email = filescanner.getArrayListPeople().get(i).getEmail(); // returns email
				Name = filescanner.getArrayListPeople().get(i).getName(); // returns name
				System.out.println("Entry number " + (i + 1) + " is: " + Name + " " + Age + " " + Email); // displays all entries
				}
			System.out.println("Please enter the two numbers of the entries you would like to check a relationship for..");
			System.out.println("First entry; ");
			input = scanner.nextInt();
			System.out.println("Second entry; ");
			input2 = scanner.nextInt();

			Email1 = filescanner.getArrayListPeople().get(input - 1).getEmail();
			Email2 = filescanner.getArrayListPeople().get(input2 - 1).getEmail();
			
			
			for(int i = 0; i < filescanner.getArrayRelationLength(); i++) {
				if(Email1.equals(filescanner.getArrayListRelation().get(i).getEmail1()) && Email2.equals(filescanner.getArrayListRelation().get(i).getEmail2())) {
						Relation = filescanner.getArrayListRelation().get(i).getRelation(); // returns relation
						Name = filescanner.getArrayListPeople().get(input - 1).getName(); // gets name string
						Name2 = filescanner.getArrayListPeople().get(input2 - 1).getName(); // gets name string
						System.out.println(Name + " and " + Name2 + " are " + Relation); // output relation
						continue mainMenu;
				} if(Email1.equals(filescanner.getArrayListRelation().get(i).getEmail2()) && Email2.equals(filescanner.getArrayListRelation().get(i).getEmail1())){
						Relation = filescanner.getArrayListRelation().get(i).getRelation(); // returns relation
						Name = filescanner.getArrayListPeople().get(input - 1).getName(); // gets name string
						Name2 = filescanner.getArrayListPeople().get(input2 - 1).getName(); // gets name for string
						System.out.println(Name + " and " + Name2 + " are " + Relation); // output relation
						continue mainMenu;
				}if(!Email1.equals(filescanner.getArrayListRelation().get(i).getEmail1()) && !Email2.equals(filescanner.getArrayListRelation().get(i).getEmail2())) {
						System.out.println("No Matches..."); // no match
						continue mainMenu;
				}
			}
		}
		
		if(input == 3) {
			int extendedFamily;
			for(int i = 0; i < filescanner.getArrayLength(); i++) { //loops array length 
				Age = filescanner.getArrayListPeople().get(i).getAge(); // returns age
				Email = filescanner.getArrayListPeople().get(i).getEmail(); // returns email
				Name = filescanner.getArrayListPeople().get(i).getName(); // returns name
				System.out.println("Entry number " + (i + 1) + " is: " + Name + " " + Age + " " + Email); // displays all entries
				}
			System.out.println("Please enter the entry number you would like to check a relationship for..");
			input = scanner.nextInt();
			tests.testOne(input);
			People newPerson = new People();
			newPerson = filescanner.getArrayListPeople().get(input - 1);			
			extendedFamily = tests.testTwo(newPerson);
			System.out.println(newPerson.getName() + " has "+ extendedFamily + " members of their extended family...");
			

			
		}
		
		}
		}
		}
	}	

